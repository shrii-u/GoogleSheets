﻿using Microsoft.EntityFrameworkCore;
using SqlToGoogleSheets_be.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlToGoogleSheets_be.Data.Data
{
    public class GoogleSheetsToSqlDbContext:DbContext
    {
        public GoogleSheetsToSqlDbContext(DbContextOptions<GoogleSheetsToSqlDbContext> options) : base(options)
        {

        }
        public DbSet<Products> Products { get; set; }
    }
}
