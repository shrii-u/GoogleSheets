﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SqlToGoogleSheets_be.Data.Models;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace SqlToGoogleSheets_be.Data.Data
{
    internal class CommonEntity
    {
        [Key]
        public int Id { get; set; }
        public DateTime CreatedOn { get; set; } = DateTime.Now;
        public DateTime? UpdatedOn { get; set; }

        [Required]

        public int CreatedBy { get; set; } = 1;


        public int? UpdatedBy { get; set; }
        public int? StatusId { get; set; }

        [ForeignKey("StatusId")]
        [ValidateNever]
        public virtual Status Status { get; set; }
    }
}
