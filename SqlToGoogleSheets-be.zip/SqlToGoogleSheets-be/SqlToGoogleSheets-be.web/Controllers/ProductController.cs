﻿using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SqlToGoogleSheets_be.BusinessLogic.GoogleSheetBL;
using SqlToGoogleSheets_be.BusinessLogic.ProductBL;
using SqlToGoogleSheets_be.Data.CustomModels;
using SqlToGoogleSheets_be.Data.Models;
using System.Net;

namespace SqlToGoogleSheets_be.web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductBusinessLogic _productBusinessLogic;
        private readonly IGoogleSheetBusinessLogic _sheetsService;

        CommonAPIConstants commonAPIConstants = new CommonAPIConstants();
        public ProductController(IProductBusinessLogic productBusinessLogic, IGoogleSheetBusinessLogic sheetsService)
        {
            _productBusinessLogic = productBusinessLogic;
            _sheetsService = sheetsService;

        }
        [HttpPost("sync")]
        public async Task<IActionResult> SyncWithGoogleSheets()
        {
            var productsFromDb = await _productBusinessLogic.GetProducts(); 
            var productsFromSheet = await _sheetsService.GetProductsFromSheet();

            var productsToUpdate = productsFromDb
                .Where(dbProduct => !productsFromSheet.Any(sheetProduct => sheetProduct.Id == dbProduct.Id
                                                                        && sheetProduct.Name == dbProduct.Name
                                                                        && sheetProduct.Price == dbProduct.Price&& sheetProduct.Description==dbProduct.Description))
                .ToList();

            if (productsToUpdate.Any())
            {
                await _sheetsService.UpdateSheet(productsToUpdate);
            }

            return Ok(productsToUpdate);
        }
        [HttpPost]
        [Route("getAll")]
        public async Task<APICommonResponse<List<Products>>> GetProductAsync()
        {
            List<Products> data = await _productBusinessLogic.GetProducts();

            if (data != null)
            {
                return new APICommonResponse<List<Products>>(true, (int)HttpStatusCode.OK, commonAPIConstants.SuccessMsg, data);
            }
            else
            {
                return new APICommonResponse<List<Products>>(false, (int)HttpStatusCode.OK, commonAPIConstants.NotFoundMsg, data);
            }
        }

        [HttpPost]
        [Route("createEdit")]
        public async Task<APICommonResponse<Products>> CreateEditProductAsync([FromBody] Products product)
        {
            Products data = new Products();
            if (product.Id == 0)
            {
                data = await _productBusinessLogic.CreateProduct(product);
            }
            else
            {
                data = await _productBusinessLogic.UpdateProduct(product);

            }
            if (data != null)
            {
                return new APICommonResponse<Products>(true, (int)HttpStatusCode.OK, commonAPIConstants.SuccessMsg, data);
            }
            else
            {
                return new APICommonResponse<Products>(false, (int)HttpStatusCode.OK, commonAPIConstants.NotFoundMsg, data);
            }
        }
        [HttpDelete]
        [Route("delete/{id}")]
        public async Task<APICommonResponse<bool>> DeleteProductAsync(int id)
        {
            var data = await _productBusinessLogic.DeleteProduct(id);

            if (data != null)
            {
                return new APICommonResponse<bool>(true, (int)HttpStatusCode.OK, commonAPIConstants.SuccessMsg, true);
            }
            else
            {
                return new APICommonResponse<bool>(false, (int)HttpStatusCode.OK, commonAPIConstants.NotFoundMsg, false);
            }
        }

        [HttpGet]
        [Route("getbyid/{id}")]
        public async Task<APICommonResponse<Products>> GetProductByIdAsync(int id)
        {
            var data = await _productBusinessLogic.GetProductById(id);

            if (data != null)
            {
                return new APICommonResponse<Products>(true, (int)HttpStatusCode.OK, commonAPIConstants.SuccessMsg, data);
            }
            else
            {
                return new APICommonResponse<Products>(false, (int)HttpStatusCode.OK, commonAPIConstants.NotFoundMsg, data);
            }
        }


    }
}
