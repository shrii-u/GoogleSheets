using SqlToGoogleSheets_be.Data.Data;
using Microsoft.EntityFrameworkCore;
using SqlToGoogleSheets_be.Repository;
using SqlToGoogleSheets_be.Data.Models;
using SqlToGoogleSheets_be.BusinessLogic.ProductBL;
using SqlToGoogleSheets_be.BusinessLogic.GoogleSheetBL;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddDbContext<GoogleSheetsToSqlDbContext>(opt => opt.UseSqlServer(builder.Configuration["ConnectionStrings:DefaultConnection"]), ServiceLifetime.Scoped);


// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped(typeof(IGenericRepository<int, Products>), typeof(GenericRepository<int, Products>));
builder.Services.AddScoped(typeof(IProductBusinessLogic), typeof(ProductBusinessLogic));

builder.Services.AddScoped<IGoogleSheetBusinessLogic>(provider =>
{
    var credentialPath = builder.Configuration["GoogleSheets:CredentialPath"];
    var spreadsheetId = builder.Configuration["GoogleSheets:SpreadsheetId"];

    return new GoogleSheetBusinessLogic(credentialPath, spreadsheetId);
});



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
