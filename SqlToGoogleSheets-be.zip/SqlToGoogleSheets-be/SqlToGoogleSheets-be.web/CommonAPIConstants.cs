﻿namespace SqlToGoogleSheets_be.web
{
    public class CommonAPIConstants
    {
        public string SuccessListMsg = "Data list generated successfully";
        public string SuccessMsg = " Data Found ";
        public string SuccessAddMsg = "Data added successfully";
        public string SucccessUpdateMsg = "Data updated successfully";
        public string SuccessDeleteMsg = "Data deleted successfully";
        public string OtpgeneratedSuccessMsg = "OTP generated sucessfully";
        public string OtpgeneratedErrorMsg = "User Not Found";
        public string BadRequestMsg = "Bad Request Error";
        public string UnauthorizedMsg = "Unauthorized User Request Error";
        public string NotFoundMsg = "Not Found Request Error";
        public string InternalServerMsg = "Internal Server Error";

        public string LoginMsg = "Login Successful";
        public string LoginError = "User Not Found ";
        public string PasswordError = "Password Incorect";
        public string ForgotPwdMsg = "Password Reset Successfully";
    }
}
