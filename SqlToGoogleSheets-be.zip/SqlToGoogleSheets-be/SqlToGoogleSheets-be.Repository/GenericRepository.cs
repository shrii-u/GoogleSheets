﻿using Microsoft.EntityFrameworkCore;
using SqlToGoogleSheets_be.Data.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace SqlToGoogleSheets_be.Repository
{
    public class GenericRepository<TKey, TEntity> : IGenericRepository<TKey, TEntity> where TEntity : class
    {
        protected readonly GoogleSheetsToSqlDbContext _dbContext;

        public GenericRepository(GoogleSheetsToSqlDbContext dbContext) : base()
        {
            _dbContext = dbContext;
        }

        public async Task<TEntity> GetByIdAsync(int id)
        {
            return await _dbContext.Set<TEntity>().FindAsync(id);
        }
        public async Task<IList<TEntity>> AllAsync()
        {
            return await _dbContext.Set<TEntity>().ToListAsync();
        }

        public async Task<bool> AddAsync(TEntity entity)
        {
            if (entity is IEntity commonEntity)
            {
                setCommonFields(commonEntity);
            }
            try
            {
                _dbContext.Set<TEntity>().Add(entity);

                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return true;
        }
        public async Task<TEntity> AddAsyncEntity(TEntity entity)
        {
            if (entity is IEntity commonEntity)
            {
                setCommonFields(commonEntity);
            }
            try
            {
                _dbContext.Set<TEntity>().Add(entity);

                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return entity;
        }
        public async Task<bool> AddAllAsync(IEnumerable<TEntity> entities)
        {
            foreach (TEntity entity in entities)
            {
                if (entity is IEntity commonEntity)
                {
                    setCommonFields(commonEntity);
                }
            }
            _dbContext.Set<TEntity>().AddRange(entities);
            await _dbContext.SaveChangesAsync();

            return true;
        }
        public async Task<bool> UpdateAsync(TEntity entity)
        {
            if (entity is IEntity commonEntity)
            {
                setCommonFields(commonEntity);
            }
            _dbContext.Entry(entity).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateAsync(IEnumerable<TEntity> entities)
        {
            foreach (TEntity entity in entities)
            {
                if (entity is IEntity commonField)
                {
                    setCommonFields(commonField);
                }
                _dbContext.Entry(entity).State = EntityState.Modified;
            }
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAsync(TEntity entity)
        {
            _dbContext.Remove(entity);
            await _dbContext.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteRangeAsync(IEnumerable<TEntity> entities)
        {
            _dbContext.Set<TEntity>().RemoveRange(entities);

            await _dbContext.SaveChangesAsync();
            return true;
        }


        public IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> criteria)
        {
            return _dbContext.Set<TEntity>().Where(criteria);
        }

        public IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> criteria, params Expression<Func<TEntity, object>>[] includeExpressions)
        {
            var query = _dbContext.Set<TEntity>().AsQueryable();

            foreach (var includeExp in includeExpressions)
            {
                query = query.Include(includeExp);
            }

            return query.Where(criteria);
        }

        public async Task<TEntity> AddAsyncEntity1(TEntity entity)
        {
            _dbContext.Set<TEntity>().Add(entity);
            await _dbContext.SaveChangesAsync();

            return entity;
        }

        public IEnumerable<TEntity> GetRange(Func<TEntity, bool> predicate)
        {
            return _dbContext.Set<TEntity>().Where(predicate).ToList();
        }


        public async Task<IQueryable<TResult>> JoinTablesAsync<T1, T2, TCommonKey, TResult>(
       T1 table1,
       T2 table2,
       Expression<Func<T1, TCommonKey>> t1KeySelector,
       Expression<Func<T2, TCommonKey>> t2KeySelector,
       Expression<Func<T1, T2, TResult>> resultSelector)
       where T1 : class
       where T2 : class
        {
            var table1Items = _dbContext.Set<T1>().ToList();
            var table2Items = _dbContext.Set<T2>().ToList();
            var dbQuery = table1Items
        .Join(
           table2Items,
            t1 => t1KeySelector.Compile()(t1),
            t2 => t2KeySelector.Compile()(t2),
            (t1, t2) => new { t1, t2 })
        .Select(t => new { t.t1, t.t2 }); // Fetch only necessary columns from the database

            var inMemoryQuery = dbQuery.AsEnumerable()  // Switch to in-memory processing
                .Select(t => resultSelector.Compile()(t.t1, t.t2));

            return await Task.FromResult(inMemoryQuery.AsQueryable());
        }

        private void setCommonFields(IEntity entity)
        {
            if (entity.CreatedBy == null)
            {
                entity.CreatedBy = 1;
                entity.CreatedOn = DateTime.Now;
            }
        }
    }
}
