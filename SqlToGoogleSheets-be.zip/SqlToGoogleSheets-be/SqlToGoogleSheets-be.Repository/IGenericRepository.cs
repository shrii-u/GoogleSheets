﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace SqlToGoogleSheets_be.Repository
{
    public interface IGenericRepository<TKey, TEntity> where TEntity : class
    {
        Task<IList<TEntity>> AllAsync();
        Task<bool> AddAsync(TEntity entity);

        Task<TEntity> AddAsyncEntity(TEntity entity);
        Task<bool> AddAllAsync(IEnumerable<TEntity> entities);
        Task<bool> UpdateAsync(TEntity entity);
        Task<bool> UpdateAsync(IEnumerable<TEntity> entities);
        Task<bool> DeleteAsync(TEntity entity);
        Task<bool> DeleteRangeAsync(IEnumerable<TEntity> entities);
        Task<TEntity> GetByIdAsync(int id);
        IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> criteria);
        IQueryable<TEntity> FilterBy(Expression<Func<TEntity, bool>> criteria,
            params Expression<Func<TEntity, object>>[] includeExpressions);
        IEnumerable<TEntity> GetRange(Func<TEntity, bool> predicate);
        Task<IQueryable<TResult>> JoinTablesAsync<T1, T2, TKey, TResult>(
        T1 table1,
        T2 table2,
        Expression<Func<T1, TKey>> t1KeySelector,
        Expression<Func<T2, TKey>> t2KeySelector,
        Expression<Func<T1, T2, TResult>> resultSelector)
        where T1 : class
        where T2 : class;
    }
}
