﻿using SqlToGoogleSheets_be.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlToGoogleSheets_be.BusinessLogic.ProductBL
{
    public interface IProductBusinessLogic
    {
        Task<List<Products>> GetProducts();
        Task<Products> CreateProduct(Products product);
        Task<Products> UpdateProduct(Products product);
        Task<Products> GetProductById(int id);
        Task<bool> DeleteProduct(int id);
    }
}
