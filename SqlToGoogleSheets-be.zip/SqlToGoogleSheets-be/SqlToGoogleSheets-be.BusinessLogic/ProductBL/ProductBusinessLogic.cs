﻿using Microsoft.EntityFrameworkCore;
using SqlToGoogleSheets_be.Data.Models;
using SqlToGoogleSheets_be.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlToGoogleSheets_be.BusinessLogic.ProductBL
{
    public class ProductBusinessLogic:IProductBusinessLogic
    {
        private readonly IGenericRepository<int,Products> _productRepository;
        public ProductBusinessLogic(IGenericRepository<int, Products> productRepository)
        {
            _productRepository = productRepository;
        }
        public async Task<Products> CreateProduct(Products product)
        {
            var data = await _productRepository.AddAsyncEntity(product);
            return data;
        }

        public async Task<bool> DeleteProduct(int id)
        {
            var data = await GetProductById(id);
            if (data == null)
            {
                return false;
            }

            await _productRepository.DeleteAsync(data);
            return true;
        }

        public async Task<List<Products>> GetProducts()
        {
            var data = await _productRepository.FilterBy(x => x.Id != 0).ToListAsync();

           

            return data.ToList();
        }

        public Task<Products> GetProductById(int id)
        {
            var data = _productRepository.GetByIdAsync(id);
            return data;
        }

        public async Task<Products> UpdateProduct(Products product)
        {
            var data = await _productRepository.GetByIdAsync(product.Id);
            if (data == null)
            {
                throw new Exception("Branch not found.");
            }
            else
            {
                data.Name = product.Name;
                data.Price = product.Price;
                data.Description = product.Description;
                
            }
            await _productRepository.UpdateAsync(data);
            return data;
        }

    }
}
