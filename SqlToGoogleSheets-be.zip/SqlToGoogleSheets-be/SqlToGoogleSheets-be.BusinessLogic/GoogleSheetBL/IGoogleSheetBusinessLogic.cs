﻿using SqlToGoogleSheets_be.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlToGoogleSheets_be.BusinessLogic.GoogleSheetBL
{
    public interface IGoogleSheetBusinessLogic
    {
        Task<List<Products>> GetProductsFromSheet();
        Task UpdateSheet(List<Products> products);
    }
}
