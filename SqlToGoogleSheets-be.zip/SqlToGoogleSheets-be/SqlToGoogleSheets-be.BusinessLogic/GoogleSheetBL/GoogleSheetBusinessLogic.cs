﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using SqlToGoogleSheets_be.Data.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace SqlToGoogleSheets_be.BusinessLogic.GoogleSheetBL
{
    public class GoogleSheetBusinessLogic : IGoogleSheetBusinessLogic
    {
        private readonly SheetsService _sheetsService;
        private readonly string _spreadsheetId;

        public GoogleSheetBusinessLogic(string credentialPath, string spreadsheetId)
        {
            _spreadsheetId = spreadsheetId;

            GoogleCredential credential;
            try
            {
                using (var stream = new FileStream(credentialPath, FileMode.Open, FileAccess.Read))
                {
                    credential = GoogleCredential.FromStream(stream)
                        .CreateScoped(SheetsService.Scope.Spreadsheets);
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to load credentials from {credentialPath}: {ex.Message}", ex);
            }

            _sheetsService = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = "My Google Sheets API",
            });
        }

        public async Task<List<Products>> GetProductsFromSheet()
        {
            var range = "Sheet1!A:C";
            var request = _sheetsService.Spreadsheets.Values.Get(_spreadsheetId, range);
            var response = await request.ExecuteAsync();

            var products = new List<Products>();
            if (response.Values != null)
            {
                foreach (var row in response.Values)
                {
                    if (row.Count >= 3 &&
                        int.TryParse(row[0]?.ToString(), out var id) &&
                        decimal.TryParse(row[2]?.ToString(), out var price))
                    {
                        products.Add(new Products
                        {
                            Id = id,
                            Name = row[1]?.ToString(),
                            Price = price
                        });
                    }
                }
            }
            return products;
        }
        public async Task UpdateSheet(List<Products> products)
        {
            if (products == null || !products.Any())
            {
                throw new ArgumentException("Product list cannot be null or empty.", nameof(products));
            }

            var range = "Sheet1!A:D";
            var headers = new List<object> { "Id", "Name", "Price", "Description" };

            // Use a List<IList<object>> for Values
            var valueRange = new ValueRange
            {
                Values = new List<IList<object>> { headers } // Start with headers
            };

            // Add product data
            foreach (var product in products)
            {
                valueRange.Values.Add(new List<object> { product.Id, product.Name, product.Price, product.Description });
            }

            try
            {
                var updateRequest = _sheetsService.Spreadsheets.Values.Update(valueRange, _spreadsheetId, range);
                updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;

                var response = await updateRequest.ExecuteAsync();
                // Optionally log or handle the response if needed
            }
            catch (Exception ex)
            {
                // Handle exceptions, e.g., logging the error
                throw new Exception($"Error updating Google Sheet: {ex.Message}", ex);
            }
        }


        //public async Task UpdateSheet(List<Products> products)
        //{
        //    if (products == null || !products.Any())
        //    {
        //        throw new ArgumentException("Product list cannot be null or empty.", nameof(products));
        //    }

        //    var range = "Sheet1!A:D";

        //    var valueRange = new ValueRange
        //    {
        //        Values = products.Select(p => (IList<object>)new List<object> { p.Id, p.Name, p.Price,p.Description }).ToList()
        //    };

        //    try
        //    {
        //        var updateRequest = _sheetsService.Spreadsheets.Values.Update(valueRange, _spreadsheetId, range);
        //        updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;

        //        var response = await updateRequest.ExecuteAsync();
        //        // Optionally log or handle the response if needed
        //    }
        //    catch (Exception ex)
        //    {
        //        // Handle exceptions, e.g., logging the error
        //        throw new Exception($"Error updating Google Sheet: {ex.Message}", ex);
        //    }
        //}


    }
}
